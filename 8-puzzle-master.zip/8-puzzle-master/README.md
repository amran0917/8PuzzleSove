# 8-puzzle
This is a Java implementation for the popular 8-puzzle problem using many search algorithms such as:
1) DFS (Depth First Search)
2) BFS (Breadth First Search)
3) Iterative Deepening
4) Uniform Cost
5) BFS(Best First Search)
6) A*
# How to run:
You need to run the App.java class. It contains the main method. In this class, you have the ability to define your initial state. You can also define the goal state. So, it is a very comprehensive solution. 
