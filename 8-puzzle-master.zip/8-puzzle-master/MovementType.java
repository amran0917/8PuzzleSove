/**
 * Created by HABDOLLA on 1/13/2016.
 * This are movement types that we do with a tile
 */
public enum MovementType {
    UP,
    DOWN,
    LEFT,
    RIGHT;
}
