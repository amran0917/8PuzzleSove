/**
 * Created by HABDOLLA on 1/20/2016.
 */
public enum Heuristic {
    H_ONE,
    H_TWO,
    H_THREE

}
